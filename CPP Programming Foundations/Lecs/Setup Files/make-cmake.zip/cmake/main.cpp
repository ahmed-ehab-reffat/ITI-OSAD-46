#include<iostream>
using namespace std;
int main() {
  cout<<"weclome...............................................................ssssssssssssssssssssssssssssssssssssssssssssssss..";
  return 0;
}